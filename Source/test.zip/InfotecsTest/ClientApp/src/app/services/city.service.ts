import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient, HttpParams } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { MatSnackBar } from '@angular/material';

@Injectable({
  providedIn: 'root',
})
export class CityService {
  private citiesUrl = 'api/cities';

  constructor(public snackBar: MatSnackBar, private http: HttpClient) { }

  /**
   * Request for cities
   * @param filter cities name filter
   */
  getCities(filter: string): Observable<string[]> {
    let options = filter ? { params: new HttpParams().set('q', filter) } : {};
    return this.http.get<string[]>(this.citiesUrl, options)
      .pipe(catchError(this.handleError('getCities', [])));
  }

  /**
   * Handle server error
   * @param operation operation name
   * @param result server result
   */
  handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      console.error(`${operation} failed: ${error.message}`);
      this.snackBar.open('При обращении к сервису произошла ошибка.');
      return of(result as T);
    };
  }
}
