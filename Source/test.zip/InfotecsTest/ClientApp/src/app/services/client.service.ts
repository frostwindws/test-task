import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { MatSnackBar } from '@angular/material';

import { Client } from '../models/client';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root',
})
export class ClientService {
  private clientsUrl = 'api/clients';

  constructor(public snackBar: MatSnackBar, private http: HttpClient) { }

  /**
   * Request for clients
   * @param filter clients filter
   */
  getClients(filter: string): Observable<Client[]> {
    let options = filter ? { params: new HttpParams().set('q', filter) } : {};
    return this.http.get<Client[]>(this.clientsUrl, options)
      .pipe(catchError(this.handleError('getClients', [])));
  }

  /**
   * Request for client update
   * @param client target client
   */
  updateClient(client: Client): Observable<any> {
    return this.http.put(this.clientsUrl, client, httpOptions).pipe(
      catchError(this.handleError<any>('updateClient'))
    );
  }

  /**
   * Request for new client add
   * @param client new client
   */
  addClient(client: Client): Observable<any> {
    return this.http.post(this.clientsUrl, client, httpOptions).pipe(
      catchError(this.handleError<any>('addClient'))
    );
  }

  /**
   * Request for client delete
   * @param client target client
   */
  deleteClient(client: Client): Observable<any> {
    return this.http.delete(this.clientsUrl + `/${client.id}`).pipe(
      catchError(this.handleError<any>('addClient'))
    );
  }
  
  /**
   * Handle server error
   * @param operation operation name
   * @param result server result
   */
  handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      console.error(`${operation} failed: ${error.message}`);
      this.snackBar.open('При обращении к сервису произошла ошибка.');
      return of(result as T);
    };
  }
}
