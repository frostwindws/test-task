export class Client {
  id: number;
  name: string;
  surname: string;
  city: string;
}
