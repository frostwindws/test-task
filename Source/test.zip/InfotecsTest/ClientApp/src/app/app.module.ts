import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatButtonModule, MatIconModule, MatTableModule, MatAutocompleteModule, MatInputModule, MatDialogModule, MatSnackBarModule } from '@angular/material';
import { CdkTableModule } from '@angular/cdk/table';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { ClientsComponent } from './components/clients/clients.component';
import { EditorComponent } from './components/editor/editor.component';
import { DeleterComponent } from './components/deleter/deleter.component';

@NgModule({
  declarations: [
    AppComponent,
    ClientsComponent,
    EditorComponent,
    DeleterComponent
  ],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    BrowserModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatIconModule,
    MatTableModule,
    MatAutocompleteModule,
    MatInputModule,
    MatDialogModule,
    MatSnackBarModule,
    CdkTableModule,
    HttpClientModule
  ],
  entryComponents: [EditorComponent, DeleterComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
