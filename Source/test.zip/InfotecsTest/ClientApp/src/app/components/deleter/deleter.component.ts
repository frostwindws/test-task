import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material';
import { Client } from '../../models/client';

@Component({
  selector: 'client-deleter',
  templateUrl: './deleter.component.html',
})
export class DeleterComponent {
  client: Client;

  constructor(@Inject(MAT_DIALOG_DATA) public data: Client) {
    this.client = data;
  }
}
