import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';

import { Client } from '../../models/client';
import { EditorComponent } from '../editor/editor.component';
import { DeleterComponent } from '../deleter/deleter.component';
import { ClientService } from '../../services/client.service';
import { FormControl } from '@angular/forms';
import { startWith, debounceTime } from 'rxjs/operators';

@Component({
  selector: 'clients-list',
  templateUrl: './clients.component.html',
  styleUrls: ['./clients.component.css']
})
export class ClientsComponent implements OnInit {
  clients: Client[];
  currentClient: Client;
  isLoading = false;
  searchCtl = new FormControl();

  constructor(public dialog: MatDialog, private clientService: ClientService) { }

  ngOnInit() {
    this.getClients('');
    this.searchCtl.valueChanges
      .pipe(startWith(''), debounceTime(500))
      .subscribe(value => this.getClients(value));
  }

  /**
   * Request for clients list
   */
  getClients(filter: string) {
    this.isLoading = true;
    this.clientService.getClients(filter)
      .subscribe(clients => {
        this.clients = clients;
        this.isLoading = false;
      });
  }

  /**
   * Init client editig
   * @param client target client
   */
  onEdit(client: Client) {
    this.currentClient = client;
    this.dialog.open(EditorComponent, {
      width: '600px',
      data: client
    }).afterClosed().subscribe(result => {
      if (result) {
        this.isLoading = true;
        this.clientService.updateClient(result)
          .subscribe(updatedClient => {
            // update client in the list
            let index = this.getIndexById(this.currentClient.id);
            let clients = this.clients.slice();
            if (index > -1) clients[index] = updatedClient;
            this.clients = clients;
            this.isLoading = false;
          });
      }
    });;
  }

  /**
   * Init client adding
   */
  onAdd() {
    this.currentClient = null;
    this.dialog.open(EditorComponent, {
      width: '600px',
      data: null
    }).afterClosed().subscribe(result => {
      if (result) {
        this.isLoading = true;
        this.clientService.addClient(result)
          .subscribe(newClient => {
            // add new client to the list
            let clients = this.clients.slice();
            clients.push(newClient);
            this.clients = clients;
            this.isLoading = false;
          });
      }
    });
  }

  /**
   * Init client deleting
   * @param client target client
   */
  onDelete(client: Client) {
    this.currentClient = client;
    this.dialog.open(DeleterComponent, {
      width: '600px',
      data: client
    }).afterClosed().subscribe(result => {
      if (result) {
        this.isLoading = true;
        this.clientService.deleteClient(this.currentClient)
          .subscribe(r => {
            // remove current client from the list
            let index = this.getIndexById(this.currentClient.id);
            let clients = this.clients.slice();
            if (index > -1) clients.splice(index, 1);
            this.clients = clients;
            this.isLoading = false;
          })
      }
    });
  }

  /**
   * Get client index in clients list by his id
   * @param id Client id
   */
  getIndexById(id: number): number {
    for (var i = 0; i < this.clients.length; i++) {
      if (this.clients[i].id === id) return i;
    }

    return -1;
  }
}
