import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Observable, of } from 'rxjs';
import { startWith, debounceTime, switchMap } from 'rxjs/operators';
import { Client } from '../../models/client';
import { CityService } from '../../services/city.service';

@Component({
  selector: 'client-editor',
  templateUrl: './editor.component.html',
  styleUrls: ['./editor.component.css']
})
export class EditorComponent implements OnInit {
  cities: Observable<string[]>;
  formData: FormGroup;

  clientId: number; // editing client identificator
  isNew: boolean; // adding client flag

  constructor(public dialogRef: MatDialogRef<EditorComponent>, @Inject(MAT_DIALOG_DATA) public data: Client, private cityService: CityService) {
    this.isNew = data == null;

    if (!this.isNew) {
      this.clientId = data.id;
    } else {
      data = { id: 0, name: '', surname: '', city: '' }
    }

    this.formData = new FormGroup({
      name: new FormControl(data.name),
      surname: new FormControl(data.surname),
      city: new FormControl(data.city),
    });
  }

  ngOnInit() {    
    this.cities = this.formData.get('city').valueChanges
      .pipe(
        startWith(''),
        debounceTime(200), // to reduce request frequency
        switchMap(value => this.getCities(value))
      );
  }

  /**
   * Request for cities
   * @param filter cities name filter
   */
  getCities(filter: string): Observable<string[]> {
    if (filter && filter.length > 3) {
      // request only for filter more than 3 letters long
      return this.cityService.getCities(filter)
    }

    return of([]);
  }

  /**
   * Components title
   */
  title(): string {
    return this.isNew ? 'Регистрация' : 'Редактирование';
  }

  /**
   * Save current client
   */
  onSave(): void {
    if (this.formData.valid) {
      this.dialogRef.close(Object.assign({ id: this.clientId || 0 }, this.formData.value));
    }
  }
}
