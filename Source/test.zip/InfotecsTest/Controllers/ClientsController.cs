﻿using System.Collections.Generic;
using System.Linq;
using InfotecsTest.Models;
using Microsoft.AspNetCore.Mvc;

namespace InfotecsTest.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ClientsController : Controller
    {
        private ClientsContext dbContext;
        public ClientsController(ClientsContext context)
        {
            dbContext = context;
        }

        // GET api/clients
        [HttpGet]
        public ActionResult<IEnumerable<Client>> Get([FromQuery(Name = "q")] string filter)
        {
            IQueryable<Client> clients = dbContext.Clients;

            // if there is filter arg - do additional filtering
            if (!string.IsNullOrEmpty(filter))
            {
                filter = filter.ToLower();
                clients = clients.Where(c => c.Name.Contains(filter) || c.Surname.Contains(filter) || c.City.Contains(filter));
            }

            return clients.OrderBy(c => c.Id).ToArray();
        }

        // PUT api/clients
        [HttpPut]
        public ActionResult<Client> Put([FromBody] Client client)
        {
            // update client
            dbContext.Clients.Update(client);
            dbContext.SaveChanges();
            return client;
        }

        // POST api/clients
        [HttpPost]
        public ActionResult<Client> Post([FromBody] Client client)
        {
            // createnew client
            dbContext.Clients.Add(client);
            dbContext.SaveChanges();
            return client;
        }

        // DELETE api/values/{id}
        [HttpDelete("{id}")]
        public void Delete(long id)
        {
            dbContext.Clients.Remove(dbContext.Clients.Find(id));
            dbContext.SaveChanges();
        }
    }
}
