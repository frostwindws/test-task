﻿using System.Collections.Generic;
using System.Linq;
using InfotecsTest.Models;
using Microsoft.AspNetCore.Mvc;

namespace InfotecsTest.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CitiesController : Controller
    {
        private ClientsContext dbContext;
        public CitiesController(ClientsContext context)
        {
            dbContext = context;
        }

        // GET api/cities
        [HttpGet]
        public ActionResult<IEnumerable<string>> Get([FromQuery(Name = "q")] string filter)
        {
            var cities = dbContext.Cities.Select(c => c.Name);

            // if there is filter arg - do additional filtering
            if (!string.IsNullOrEmpty(filter))
            {
                filter = filter.ToLower();
                cities = cities.Where(c => c.ToLower().Contains(filter));
            }

            return cities.OrderBy(c => c).ToArray();
        }
    }
}