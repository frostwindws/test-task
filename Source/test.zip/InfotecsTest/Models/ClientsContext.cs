﻿using Microsoft.EntityFrameworkCore;

namespace InfotecsTest.Models
{
    /// <summary>
    /// Context for clients database
    /// </summary>
    public class ClientsContext : DbContext
    {
        /// <summary>
        /// Set of clients data
        /// </summary>
        public DbSet<Client> Clients { get; set; }

        /// <summary>
        /// Set of cities data
        /// </summary>
        public DbSet<City> Cities { get; set; }

        public ClientsContext(DbContextOptions<ClientsContext> options)
            : base(options)
        {
            Database.EnsureCreated();
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Database seed
            modelBuilder.Entity<City>().HasData(
                new City { Id = 1, Name = "Москва" },
                new City { Id = 2, Name = "Санкт-Петербург" },
                new City { Id = 3, Name = "Иваново" },
                new City { Id = 4, Name = "Казань" },
                new City { Id = 5, Name = "Махачкала" },
                new City { Id = 6, Name = "Владимир" },
                new City { Id = 7, Name = "Тверь" },
                new City { Id = 8, Name = "Калининград" },
                new City { Id = 9, Name = "Омск" },
                new City { Id = 10, Name = "Дмитров" },
                new City { Id = 11, Name = "Челябинск" });

            modelBuilder.Entity<Client>().HasData(
                  new Client { Id = 4, Name = "Иван", Surname = "Иванов", City = "Москва" },
                  new Client { Id = 5, Name = "Петр", Surname = "Петров", City = "Иваново" },
                  new Client { Id = 6, Name = "Семен", Surname = "Семенов", City = "Калининград" },
                  new Client { Id = 7, Name = "Сидор", Surname = "Сидоров", City = "Омск" },
                  new Client { Id = 8, Name = "Кузьма", Surname = "Кузнецов", City = "Калининград" }
                );
        }
    }
}
